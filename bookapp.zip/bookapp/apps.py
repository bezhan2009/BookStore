from django.apps import AppConfig


class BookApp(AppConfig):
    name = "bookapp"
