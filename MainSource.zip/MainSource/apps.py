from django.apps import AppConfig


class MainSource(AppConfig):
    name = 'MainSource'
